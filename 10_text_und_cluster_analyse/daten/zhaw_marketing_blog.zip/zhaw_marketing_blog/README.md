# Dateien aus dem ZHAW Marketing Management Blog 

Quelle: https://blog.zhaw.ch/marketingmanagement/

Alle Bilder wurden für die Analyse entfernt. 

Die Daten sind wie folgt organisiert: 

- Verzeichnis `text` enthält die Rohtexte im "Nur Text" -Format.
- Verzeichnis `unkodiert` enthält die Rohtexte im Word-Format.
- Verzeichnis `kodiert` enthält die kodierten Texte im Word-Format. 

## Kodierung 

Die Kodierung prüft die Art von Substantiven in den Texten sowie das verwendete Geschlecht (feminin, neutral oder maskulin). 

Die Kodierung ist immer paarweise in einem Kommentar. Für manche Begriffe liegen zwei Kodierungen vor.

Die folgenden Kodierungen wurden verwendet: 

Akteure
- person
- organisation
- gruppe

Studiengang
- cas
-bsc
-mas
-msc

Funktion
- aktivität
- eigenschaft
- fähigkeit
- möglichkeit
- funktion
- produkt
- anwendung

Kontext 
- kontext
- konzept
- technik
- zeit
- information